Clipboard V1.0.0 Update (January 2019)
===========================================

Thank you for purchasing this item, included in this set should be the following:

(Notes: This product uses the Unity Standard Shaders)
     

	-1 Assets
	-1 Prefabs (Seperated into Clean & Dirty)
	-7 1024x1024 textures
	-1 Scene
	-1024 polys